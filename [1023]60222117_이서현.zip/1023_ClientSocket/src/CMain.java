public class CMain {
	
	private void run() {
		View view = new View();
		view.showUserInfo();
	}
	
	public static void main(String[] args) {
		CMain main = new CMain();
		main.run();
	}
}