
public class CSearch extends Stub implements ICSearch{
	private String ipNumber;
	private int portNumber;
	private String objectName;
	private String methodName;
	private String args;
	private String token;

	public CSearch(ComputerInfo computerInfo, ObjectInfo objectInfo, String token) {
		super(computerInfo.getIpNumber(), computerInfo.getPortNumber());
		this.ipNumber = computerInfo.getIpNumber();
		this.portNumber = computerInfo.getPortNumber();
		this.objectName = objectInfo.getObjectName();
		this.methodName = objectInfo.getMethodName();
		this.args = objectInfo.getArgs();
		this.token = token;
	}
	public void searchCourse() {
		this.request(this.objectName, this.methodName, this.args+" "+token);
	}

}
