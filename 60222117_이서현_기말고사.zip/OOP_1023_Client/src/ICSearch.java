
public interface ICSearch {
	void searchCourse();
}
