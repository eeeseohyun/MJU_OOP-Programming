
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

public interface ICLogin {
	String login(String string) throws NoSuchAlgorithmException, UnsupportedEncodingException;
}