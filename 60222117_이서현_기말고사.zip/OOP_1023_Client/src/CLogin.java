
public class CLogin extends Stub implements ICLogin {
	private String ipNumber;
	private int portNumber;
	private String objectName;
	private String methodName;
	private String args;
	
	public CLogin(ComputerInfo computerInfo, ObjectInfo objectInfo) {
		super(computerInfo.getIpNumber(), computerInfo.getPortNumber());
		this.ipNumber = computerInfo.getIpNumber();
		this.portNumber = computerInfo.getPortNumber();
		this.objectName = objectInfo.getObjectName();
		this.methodName = objectInfo.getMethodName();
		this.args = objectInfo.getArgs();
	}
	
	public String login(String userInfo) {
		String token = this.request(this.objectName, this.methodName, this.args);
		return token;
	}
}