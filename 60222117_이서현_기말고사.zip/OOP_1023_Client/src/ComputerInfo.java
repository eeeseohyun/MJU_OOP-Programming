
public class ComputerInfo {
	private String iPNumber;
	private int portNumber;
	public ComputerInfo(String ipNumber,int portNumber) {
		this.iPNumber = ipNumber;
		this.portNumber = portNumber;
	}
	public String getIpNumber() {
		return this.iPNumber;
	}
	public int getPortNumber() {
		return this.portNumber;
	}
}
