import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class CMain {
	private static Scanner reader = new Scanner(System.in);
	private void run() throws NoSuchAlgorithmException {
		try {
			ComputerInfo computerInfo = getComputerInfo(); // localhost 12345
			ObjectInfo objectInfo = getObjectInfo(); //Clogin login
			View view = new View(computerInfo,objectInfo);
			String token = view.login();
			
			if(token!=null) {
				view.setToken(token);
				objectInfo = getObjectInfo();
				view.reStart(objectInfo);
				view.getCourse();
			}
			objectInfo = getObjectInfo();
			view.reStart(objectInfo);
			view.registrate();
		} catch (IOException e) { 
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		CMain main = new CMain();
		try {
			main.run();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private ObjectInfo getObjectInfo() throws IOException {
		System.out.println("Object Name과 Object method, args를 입력하세요");
		System.out.print("ObjectName: ");
		String objectName = reader.nextLine();
		System.out.println(objectName);
		System.out.print("ObjectMethod: ");
		String objectMethod = reader.nextLine();
		System.out.print("Args: ");
		String args = reader.nextLine();
		if(args.isEmpty() || args.trim().isEmpty()) {
			args="";
		}
		ObjectInfo objectInfo = new ObjectInfo(objectName,objectMethod,args);
		return objectInfo;
	}
	private ComputerInfo getComputerInfo() throws IOException {
		System.out.println("IP번호와 Port번호를 입력하세요.");
		System.out.print("IP번호:"); 
		String ipNumber = reader.nextLine();
		System.out.print("Port번호:");
		int portNumber = reader.nextInt();
		reader.nextLine();
		ComputerInfo computerInfo = new ComputerInfo(ipNumber,portNumber);
		return computerInfo;
	}
}