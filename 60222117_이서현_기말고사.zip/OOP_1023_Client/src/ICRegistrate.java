
public interface ICRegistrate {
	void registrate();
}
