import java.util.ArrayList;

public class ObjectInfo {
	private String objectName;
	private String methodName;
	private String args;
	
	public ObjectInfo(String objectName,String methodName,String args) {
		this.objectName = objectName;
		this.methodName = methodName;
		this.args = args;
	}
	public String getObjectName() {
		return this.objectName;
	}
	public String getMethodName() {
		return this.methodName;
	}
	public String getArgs() {
		return this.args;
	}
}
