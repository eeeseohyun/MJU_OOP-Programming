import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

public class View {
	private ICLogin cLogin;
	private ICSearch cSearch;
	private ICRegistrate cRegistrate;
	private String token;
	private ObjectInfo objectInfo;
	private ComputerInfo computerInfo;
	public View(ComputerInfo computerInfo, ObjectInfo objectInfo) {
		this.cLogin = new CLogin(computerInfo,objectInfo);
		this.objectInfo = objectInfo;
		this.computerInfo= computerInfo;
	}
	public void setToken(String token) {
		this.token =token;
	}
	public void reStart(ObjectInfo objectInfo) {
		this.objectInfo = objectInfo;
	}
	
	public String login() throws NoSuchAlgorithmException, UnsupportedEncodingException{
		token = this.cLogin.login(objectInfo.getArgs());
		return token;
	}
	public void getCourse() {
		this.cSearch= new CSearch(computerInfo, objectInfo, token);
		this.cSearch.searchCourse();
	}
	public void registrate() {
		this.cRegistrate = new CRegistrate(computerInfo,objectInfo,token);
		this.cRegistrate.registrate();
	}
}
