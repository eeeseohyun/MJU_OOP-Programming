
public class CRegistrate extends Stub implements ICRegistrate {
	private String ipNumber;
	private int portNumber;
	private String objectName;
	private String methodName;
	private String args;
	private String token;
	
	public CRegistrate(ComputerInfo computerInfo, ObjectInfo objectInfo, String token) {
		super(computerInfo.getIpNumber(), computerInfo.getPortNumber());
		this.ipNumber = computerInfo.getIpNumber();
		this.portNumber = computerInfo.getPortNumber();
		this.objectName = objectInfo.getObjectName();
		this.methodName = objectInfo.getMethodName();
		this.args = objectInfo.getArgs();
		this.token = token;
	}
	public void registrate() {
		this.request(this.objectName, this.methodName, this.args+" "+token);
	}
}
