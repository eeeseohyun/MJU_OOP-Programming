package Dto;

import java.util.ArrayList;

public class ObjectInfo {
	private String objectName;
	private String methodName;
	private ArrayList<String> args;
	
	public ObjectInfo(String objectName,String methodName,ArrayList<String> args) {
		this.objectName = objectName;
		this.methodName = methodName;
		this.args = args;
	}
	public String getObjectName() {
		return this.objectName;
	}
	public String getMethodName() {
		return this.methodName;
	}
	public ArrayList<String> getArgs() {
		return this.args;
	}
}
