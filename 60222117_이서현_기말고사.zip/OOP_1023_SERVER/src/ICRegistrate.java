
public interface ICRegistrate {
	String registrate(String info);
}
