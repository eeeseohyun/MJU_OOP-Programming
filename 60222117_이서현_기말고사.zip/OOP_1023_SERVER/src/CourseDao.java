import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CourseDao {
	public DatabaseConnection database;
	public CourseDao() {
		this.database = new DatabaseConnection();
	}
	public String getCourse(){
		String courses = "";
		Connection con = null;
		Statement state = null;
		try {
			con = database.getConnection();
			state = con.createStatement();
			String sql = "SELECT * FROM COURSE";
			ResultSet rs = state.executeQuery(sql);
			while(rs.next()) {
				String courseId = rs.getString("courseID");
				String courseName = rs.getString("courseName");
				String professor = rs.getString("professor");
				String courseTime = rs.getString("courseTime");
				courses = courses+courseId+" "+courseName+" "+professor+" "+courseTime+"\n";
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return courses;
	}
}
