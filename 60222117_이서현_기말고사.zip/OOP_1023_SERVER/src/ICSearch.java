
public interface ICSearch {
	String searchCourse(String token);
}
