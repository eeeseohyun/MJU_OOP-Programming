import java.util.ArrayList;

public class CSearch implements ICSearch{
	public DatabaseConnection database;
	private TokenDao tokenDao;
	private CourseDao courseDao;
	public CSearch() {
		this.database = new DatabaseConnection(); 
		this.tokenDao = new TokenDao();
		this.courseDao = new CourseDao();
	}
	public String searchCourse(String token) {
		if(!checkToken(token)) {
			return "올바르지 않은 접근입니다.";
		}
		return courseDao.getCourse();
		
		
	}
	private boolean checkToken(String token) {
		boolean result=true;
		ArrayList<String> tokens = tokenDao.getToken();
		for(String data : tokens) {
			if(data.equals(token)) {
				result = true;
			}	
		}
		return result;
	}

}
