import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

public interface ICLogin {
	String login(String userInfo) throws NoSuchAlgorithmException, UnsupportedEncodingException;
}
