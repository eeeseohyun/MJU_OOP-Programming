import java.util.ArrayList;
import java.util.StringTokenizer;

public class CRegistrate implements ICRegistrate{
	public DatabaseConnection database;
	private TokenDao tokenDao;
	private RegistrateDao registrateDao;
	public CRegistrate() {
		this.database = new DatabaseConnection(); 
		this.tokenDao = new TokenDao();
		this.registrateDao = new RegistrateDao();
	}
	private boolean checkToken(String token) {
		boolean result=true;
		ArrayList<String> tokens = tokenDao.getToken();
		for(String data : tokens) {
			if(data.equals(token)) {
				result = true;
			}	
		}
		return result;
	}
	public String registrate(String Info) {
		String studentID;
		String courseID;
		String token;
		StringTokenizer tokenizer = new StringTokenizer(Info);
	
		studentID= tokenizer.nextToken();
		courseID = tokenizer.nextToken();
		token = tokenizer.nextToken();
		
		if(!checkToken(token)) {
			return "올바르지 않은 접근입니다.";
		}
		registrateDao.registrate(studentID,courseID);
		return registrateDao.getRegistration();
		
	}
}
