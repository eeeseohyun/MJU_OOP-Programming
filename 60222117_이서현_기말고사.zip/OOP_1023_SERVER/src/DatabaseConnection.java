import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	private final String jdbcUrl = "jdbc:mysql://localhost/opp";
	private final String username = "root";
	private final String password = "shsh0615";
	private final String driverClassName = "com.mysql.cj.jdbc.Driver";

	public Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName(driverClassName);
		return (DriverManager.getConnection(jdbcUrl,username,password));
	}
	
}

