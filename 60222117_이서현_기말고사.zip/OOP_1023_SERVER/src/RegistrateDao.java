import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class RegistrateDao {
	public DatabaseConnection database;
	public RegistrateDao() {
		this.database = new DatabaseConnection();
	}
	public void registrate(String studentId, String courseID) {
		Connection con = null;
		PreparedStatement state = null;
		try {
			con = database.getConnection();
			String sql = "INSERT INTO registrate (studentID,courseID) VALUES (?,?)"; 
			state = con.prepareStatement(sql);
			state.setString(1,studentId);
			state.setString(2, courseID);
			int rowsAffected = state.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getRegistration() {
		ArrayList<String> tokens = new ArrayList<String>();
		Connection con = null;
		Statement state = null;
		String result="";
		try {
			con = database.getConnection();
			state= con.createStatement();
			String sql = "SELECT * FROM registrate";
			ResultSet rs = state.executeQuery(sql);
			
			while(rs.next()) {
				String studentId = rs.getString("studentID");
				String courseId = rs.getString("courseID");
				result = result + studentId + " " + courseId + "\n";
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
