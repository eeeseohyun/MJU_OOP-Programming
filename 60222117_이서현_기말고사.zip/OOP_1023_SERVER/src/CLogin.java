import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class CLogin implements ICLogin {
	public DatabaseConnection database;
	private TokenDao tokenDao;
	public CLogin() {
		this.database = new DatabaseConnection(); 
		this.tokenDao = new TokenDao();
	}
	public String login(String userInfo) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		String errorString=null;
		String[] userArray = userInfo.split(" "); 
		String userId = userArray[0];
		String password = userArray[1];
		ArrayList<UserInfo> userList = getUserInfo();
		if(!checkUser(userList,userId,password)) {
			String error = "존재하지 않는 계정입니다. "+"userID: "+ userId+" password: "+password;
			return error;
		}
		SecretKey secretkey = createSecretKey();
		byte[] requestTokenByte = secretkey.getEncoded();
		String tokenString = Base64.getEncoder().encodeToString(requestTokenByte);
		return tokenString;
	}
	private SecretKey createSecretKey() throws NoSuchAlgorithmException, UnsupportedEncodingException {
		SecretKey secretkey= SecretKey();
		byte[] requestTokenByte = secretkey.getEncoded();
		String tokenString = Base64.getEncoder().encodeToString(requestTokenByte);
		tokenDao.setToken(tokenString);
		return secretkey;
	}
	
	private SecretKey SecretKey() throws NoSuchAlgorithmException {
		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(256); 
        SecretKey secretKey = keyGenerator.generateKey();
        return secretKey;
	}
	private boolean checkUser(ArrayList<UserInfo> userList, String userId, String password) {
		for(int i=0; i<userList.size();i++) {
			if(!userList.get(i).getUserId().equals(userId)) {
				return false;
			}
			if(userList.get(i).getPassword().equals(password)) {
				return true;
			}
		}
		return false;
	}
	public ArrayList<UserInfo> getUserInfo() {
		ArrayList<UserInfo> arr = new ArrayList<UserInfo>();
		Connection con = null;
		Statement state = null;
		try {
			con=database.getConnection();
			state=con.createStatement();
			String sql = "SELECT * FROM user";
			ResultSet rs = state.executeQuery(sql);
			
			while (rs.next()) {
				String userId = rs.getString("userId");
				String password = rs.getString("password");
				
				UserInfo userInfo = new UserInfo(userId,password);
				arr.add(userInfo);
			}
			rs.close();
			state.close();
			con.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}finally {
			try {
				if (state != null) {
					state.close();
				}
			} catch (SQLException ex1) {

			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex1) {

			}
		}
		return arr;
	}
}
