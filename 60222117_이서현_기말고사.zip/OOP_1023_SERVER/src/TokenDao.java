import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class TokenDao {
	public DatabaseConnection database;
	public TokenDao() {
		this.database = new DatabaseConnection();
	}
	public void setToken(String tokenString) {
		Connection con = null;
		PreparedStatement state = null;
		try {
			con = database.getConnection();
			String sql = "INSERT INTO token (token) VALUES (?)"; 
			state = con.prepareStatement(sql);
			state.setString(1,tokenString);
			 int rowsAffected = state.executeUpdate();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public ArrayList<String> getToken(){
		ArrayList<String> tokens = new ArrayList<String>();
		Connection con = null;
		Statement state = null;
		try {
			con = database.getConnection();
			state= con.createStatement();
			String sql = "SELECT * FROM Token";
			ResultSet rs = state.executeQuery(sql);
			while(rs.next()) {
				String token = rs.getString("token");
				tokens.add(token);
			}
			rs.close();
			state.close();
			con.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tokens;
		
	}
}
