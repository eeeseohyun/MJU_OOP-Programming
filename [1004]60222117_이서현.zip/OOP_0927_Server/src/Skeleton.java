import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class Skeleton {
	HashMap<String, Object> objectMap;
	public Skeleton() {
		this.objectMap =new HashMap<String,Object>();
		this.objectMap.put("control", new Control());
	}
	public void process() {
		final int Port = 1234;
		
		try {
			ServerSocket serverSocket = new ServerSocket(Port);
			
			while(true) {
				System.out.println("서버가 시작되었습니다. 포트:"+Port);
				Socket clientSocket = serverSocket.accept();
				System.out.println("클라이언트가 연결되었습니다.");
				//스레드를 통해 작업자에게 줌.
				BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
				PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(),true);
				
				String objectName =null;
				String methodName =null;
				String args =null;
				while((objectName = reader.readLine())!=null) {
					methodName = reader.readLine();
					args = reader.readLine();
					System.out.println("클라이언트로부터 받은 메시지: "+ objectName+methodName+args);
					
					Object object = this.objectMap.get(objectName);
					
					writer.println("test");
				}
				clientSocket.close();
				System.out.println("client disconnected:"+clientSocket.getInetAddress());
			}
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}
