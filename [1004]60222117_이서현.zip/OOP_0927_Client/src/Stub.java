import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Stub {
	
	private String server_IP;
	private int server_port;
	
	public Stub(String server_IP, int server_port) {
		this.server_IP= server_IP;
		this.server_port = server_port;
	}
	public String request(String objectName, String methodName, String args) {
		try {
			Socket socket = new Socket(server_IP,server_port);
			System.out.println("stub connected to skeletonS");
			
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
			
			out.println(objectName);
			out.println(methodName);
			out.println(args);
			
			System.out.println("stub message sent to skeleton: "+ objectName + methodName + args);
			
			String userInfo = in.readLine();
			System.out.println("message received from server: "+ userInfo);
			
			socket.close();
			
			return userInfo;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
}
