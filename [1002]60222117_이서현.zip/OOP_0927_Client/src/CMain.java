
public class CMain {

	private void run() {
		View view = new View();
		view.showUserInfo();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CMain main = new CMain();
		main.run();
	}

}
