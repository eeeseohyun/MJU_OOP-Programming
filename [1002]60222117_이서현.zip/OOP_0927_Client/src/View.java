
public class View {
	private Stub control;
	public View() {
		this.control = new Stub();
	}
	public void showUserInfo() {
		String userInfo = this.control.getUserInfo();
		System.out.println(userInfo);
		
	}
}
